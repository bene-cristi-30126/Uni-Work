#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char *nume;
    float pret;
    char *calificare;
    char *data;
    char *denumire;
} DATE_UTILE;

typedef struct nod
{
    DATE_UTILE *date_utile;
    struct nod *prec, *urm;
} NOD;

typedef struct
{
    NOD *prim, *ultim, *crt;
    int dimensiune;
} LISTA;

DATE_UTILE *Aloca_date(char *nume,  char *denumire,char * data, float pret, char *calificare)
{
    DATE_UTILE *d = (DATE_UTILE *)malloc(sizeof(DATE_UTILE));

    d->nume = (char *)malloc((strlen(nume) + 1) * sizeof(char));
    strcpy(d->nume, nume);

    d->pret = pret;

    d->calificare = (char *)malloc((strlen(calificare) + 1) * sizeof(char));
    strcpy(d->calificare, calificare);

    d->data = (char *)malloc((strlen(data) + 1) * sizeof(char));
    strcpy(d->data, data);

    d->denumire = (char *)malloc((strlen(denumire) + 1) * sizeof(char));
    strcpy(d->denumire, denumire);

    return d;
}

NOD *Aloca_NOD(DATE_UTILE *d)
{
    NOD *nod = (NOD *)malloc(sizeof(NOD));
    nod->prec = nod->urm = NULL;
    nod->date_utile = d;
    return nod;
}

LISTA *Aloca_lista()
{
    LISTA *l = (LISTA *)malloc(sizeof(LISTA));
    l->prim = l->ultim = NULL;
    l->dimensiune = 0;
    return l;
}

void Adauga(LISTA **l, char *buf)
{
    char nume[100];
    float pret;
    char calificare[100];
    char data[100];
    char denumire[100];

    char delim[] = ",";
    char *token = NULL;
    token = strtok(buf, delim);

    int i = 0;
    while (token != NULL)
    {
        switch (i)
        {
            case 0:
            {
                strcpy(nume, token);
                break;
            }
            case 1:
            {
                strcpy(denumire, token);
                break;
            }
            case 2:
            {
                strcpy(data, token);
                break;
            }
            case 3:
            {
                pret = atof(token);
                break;
            }
            case 4:
            {
                strcpy(calificare, token);
                break;
            }
        }
        i++;
        token = strtok(NULL, delim);
    }

    DATE_UTILE *date = Aloca_date(nume, denumire, data, pret, calificare);
    NOD *nod = Aloca_NOD(date);

    (*l)->crt = (*l)->prim;

    while ((*l)->crt)
    {
        if (strcmp(nod->date_utile->nume, (*l)->crt->date_utile->nume) > 0)
        {
            (*l)->crt = (*l)->crt->urm;
        }
        else
        {
            if (strcmp(nod->date_utile->nume, (*l)->crt->date_utile->nume) == 0)
            {
                if (nod->date_utile->data < (*l)->crt->date_utile->data)
                {
                    (*l)->crt = (*l)->crt->urm;
                }
                else
                {
                    break;
                }
            }
            else
            {
                break;
            }
        }
    }

    if((*l)->crt == 0)
    {
        if((*l)->prim == 0)
        {
            (*l)->prim = nod;
            (*l)->ultim = nod;
            (*l)->prim->prec = 0;
            (*l)->prim->urm = 0;
        }
        else
        {
            nod->urm = 0;
            nod->prec = (*l)->ultim;
            (*l)->ultim->urm = nod;
            (*l)->ultim = nod;
        }
    }
    else
    {
        if ((*l)->crt == (*l)->prim)
        {
            nod->urm = (*l)->prim;
            nod->prec = 0;
            (*l)->prim->prec = nod;
            (*l)->prim = nod;
        }
        else
        {
            nod->urm = (*l)->crt;
            nod->prec = (*l)->crt->prec;
            (*l)->crt->prec->urm = nod;
            (*l)->crt->prec = nod;
        }
    }

    (*l)->dimensiune++;
}

void Creare(LISTA *l)
{
    FILE *f = fopen("CERTIFIC.txt", "r");

    if (!f)
        return;
    char buf[100];

    int linie = 0;
    while (!feof(f))
    {
        buf[0] = '\0';
        linie++;

        fgets(buf, 100, f);
        if (linie == 1)
            continue;

        if (strlen(buf) > 0)
            Adauga(&l, buf);
    }

    fclose(f);
}

void Afisare(LISTA *l)
{
    l->crt = l->prim;
    while (l->crt)
    {
        printf("%s %s %s %f %s",
                l->crt->date_utile->nume, l->crt->date_utile->denumire,
                l->crt->date_utile->data, l->crt->date_utile->pret,
                l->crt->date_utile->calificare);

        l->crt = l->crt->urm;
    }
}



int main()
{
    int optiune;
    char nume[100], data[100], denumire[100], calificare[100];
    float pret;
    LISTA *l = Aloca_lista();

    printf("Pentru afisare lista apasati 1");
    Creare(l);

    while (1)
    {
        scanf("%d", &optiune);

        switch (optiune)
        {
            case 1:
            {
                Afisare(l);
                break;
            }
            case 0:
            {
                printf("La revedere...");
                return 0;
            }
            default:
            {
                printf("optiune gresita...\n");
                break;
            }
        }
    }

    return 0;
}
