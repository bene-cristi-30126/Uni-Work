#include <stdio.h>
#include <stdlib.h>

typedef struct tip_nod
{
        char c;
        struct tip_nod *st, *dr;
} TIP_NOD;

TIP_NOD *construire( )
{
    TIP_NOD *p = NULL;
    char c;
    scanf("%c", &c);
    if(c != '*')
    {
        p=(TIP_NOD *)malloc(sizeof(TIP_NOD));
        p->c = c;
        p->st = construire( );
        p->dr = construire( );
    }
    return p;
}

void preordine(TIP_NOD *p, int nivel)
{
    int i;
    if (p != 0)
    {
        for(i = 0; i <= nivel; i++)printf(" ");
        printf("%c\n", p->c);
        preordine(p->st, nivel+1);
        preordine(p->dr, nivel+1);
    }
}

int main()
{
    TIP_NOD *radacina;
    printf("\nIntroduceti informatia din nod in preordine ");
    radacina = construire();
    preordine(radacina, 0);
    return 0;
}
